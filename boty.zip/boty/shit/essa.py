import discord

client = discord.Client(intents=discord.Intents.all())

@client.event
async def on_message(message):
    # Ticket System
    if message.content.startswith('!ticket'):
        # Create the ticket
        ticket_channel = await message.author.create_dm()
        await ticket_channel.send('zrobione!')

        # Get the ticket category
        ticket_category = discord.utils.get(message.guild.categories, name='Tickets')
        ticket_text = await message.guild.create_text_channel('ticket-{}'.format(message.author.id), category=ticket_category)
        await ticket_text.set_permissions(message.author, read_messages=True, send_messages=True)
        await ticket_text.set_permissions(message.guild.default_role, read_messages=False)
        admin_role = discord.utils.get(message.guild.roles, id="1064985197428346880")
        await ticket_text.set_permissions(admin_role, read_messages=True)
        await ticket_text.send('Hi {}! powiedz z czym potrzebujesz pomocy a admin ci pomoże'.format(message.author.mention))

    if message.content.startswith('!close'):
        ticket_channel = discord.utils.get(message.guild.channels, name='ticket-{}'.format(message.author.id))
        await ticket_channel.delete()
        
client.run('MTA2ODIzNTE3Njg4ODUyMDgwNA.GHrofY.kibIpl2sr82DVzJY5WaaaVXjcuOPLn84m7vi1M')