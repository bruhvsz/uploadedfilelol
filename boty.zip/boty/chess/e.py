import discord

import time
client = discord.Client(intents=discord.Intents.all())



warnings = {}

@client.event
async def on_message(message):
    if message.content.startswith('nigga'):
        await message.channel.send('automod halo')
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        time.sleep(3)
        await message.delete()
    if message.content.startswith('huj'):
        await message.channel.send('automod halo')
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        time.sleep(3)
        await message.delete()
    if message.content.startswith('hwdp'):
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        await message.channel.send('automod halo')
        time.sleep(3)
        await message.delete()
    if message.content.startswith('ale chujowy server'):
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        await message.channel.send('automod halo')
        time.sleep(3)
        await message.delete()
    if message.content.startswith('dick'):
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        await message.channel.send('automod halo')
        time.sleep(3)
        await message.delete()
    if message.content.startswith('niger'):
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        await message.channel.send('automod halo')
        time.sleep(3)
        await message.delete()
    if warnings[message.author.id] == 3:
            # Add "muted" role
            role = discord.utils.get(message.guild.roles, name="muted")
            await message.author.add_roles(role)

            await message.delete()
            await message.channel.send('wpierdol stachu wpierdol')
client.run('MTA2ODgzMDMwNjU1NzI0NzUxMQ.GqiEfh.8ix_nQlrmWJpSlmqAxqhDkBCEsHSVawl9lPdXI')