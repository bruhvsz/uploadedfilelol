import discord
from discord.ext import commands
import fuzzywuzzy

words_to_moderate = ['fuck', 'dick', 'kurwa']
bot = commands.Bot(command_prefix='.', intents=discord.Intents.all())
client = discord.Client(intents=discord.Intents.all())
# dictionary to store users and their warnings
warnings = {}

@client.event
async def on_message(message):
    if message.content.startswith('automod halo'):
        await message.channel.send('dobra naprawi się zbychu masz warna')
        time.sleep(3)
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1
        await message.delete()
    
    if message.author == client.user:
        return
    # Check for words
    if any(word in message.content.lower() for word in words_to_moderate):
        # Increment user's warning count
        warnings[message.author.id] = warnings.get(message.author.id, 0) + 1

        # Check if user has 3 warnings
        if warnings[message.author.id] == 3:
            # Add "muted" role
            role = discord.utils.get(message.guild.roles, name="muted")
            await message.author.add_roles(role)

            await message.delete()
            await message.channel.send('wpierdol stachu wpierdol')
    # Check for URLs
    else:
        # Find all URLs in the message
        urls = discord.utils.find_urls(message.content)

        # If the message contains a URL, increment warning count
        if len(urls) > 0:
            warnings[message.author.id] = warnings.get(message.author.id, 0) + 1

            # Check if user has 3 warnings
            if warnings[message.author.id] == 3:
                # Add "muted" role
                role = discord.utils.get(message.guild.roles, name="muted")
                await message.author.add_roles(role)

    await message.delete()
    await message.channel.send('ostrzezenie')
    


client.run('MTA2ODIxMzA2MTIxMjcwNDgxOQ.GqtaDI.6lxvW2Kd82zkhnHk2iFkNfWMvQJdHrOCaazZM0')